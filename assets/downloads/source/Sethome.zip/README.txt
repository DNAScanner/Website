Deutsch : Ich hafte nicht für Tode hinter/in der Worldboarder, da man hinter der Worldboarder keinen Damage entfernen kann.
English : I am not responsible for dead people behind / in the world border because you cannot remove damage behind the worldboarder.
Français : Je ne suis pas responsable des morts derrière / dans la frontière mondiale parce que vous ne pouvez pas supprimer les dommages derrière le Worldboarder.
Italiano : Non sono responsabile per i morti dietro / al confine mondiale, perché non è possibile rimuovere i danni dietro il worldboarder.